def handleTimerEvent():
	"""Move the simulated package while Vfd101 is running."""
	basePath = "[default]Exchange/VLock/Default"
	paths = [basePath + "/Vfds/Vfd101/Running", basePath + "/PackageX"]
	values = system.tag.readBlocking(paths)
	if not all(value.quality.isGood() for value in values):
		return
	if not bool(values[0].value) or values[1].value is None:
		return
	x = float(values[1].value) + 0.00695
	if x >= 0.83:
		x = 0.135
	system.tag.writeBlocking([basePath + "/PackageX"], [x])
