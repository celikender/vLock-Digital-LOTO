SELECT
    id,
    equipment_name,
    event_type,
    username,
    reason,
    event_time
FROM public.ex_vlock_loto_events
ORDER BY event_time DESC, id DESC
LIMIT 50;