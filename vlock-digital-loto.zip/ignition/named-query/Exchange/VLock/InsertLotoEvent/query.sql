INSERT INTO public.ex_vlock_loto_events
    (equipment_name, event_type, username, reason)
VALUES
    (:equipmentName, :eventType, :username, :reason);